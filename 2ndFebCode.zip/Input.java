import java.io.IOException;
import java.util.Scanner;

// import java.util.*;
class SUM {
    public static void main(String... args) throws IOException {
        // String firstName = args[0];
        // String lastName = args[1];
        // System.out.println("This is the name :" + firstName + lastName);

        // if (args.length == 2) {
        // int num1 = Integer.parseInt(args[0]);
        // int num2 = Integer.parseInt(args[1]);
        // int res = num1 + num2;
        // System.out.println("This is the sum :" + res);
        // } else {
        // System.out.println("Not a valid input");
        // }

        // int sum = 0;
        // for (int i = 0; i < args.length; i++) {
        // sum = sum + Integer.parseInt(args[i]);
        // }
        // System.out.println("This is the sum :" + sum);

        // System.out.println("Please enter a value");
        // // int val = System.in.read();
        // byte [] val = System.in.readAllBytes();
        // System.out.println("This is the value :" + val);

        // Scanner scanner = new Scanner(System.in);
        // System.out.println("Please enter your roll no");
        // int rollNo = scanner.nextInt();
        // System.out.println("This is the roll NO :" + rollNo);
        // scanner.nextLine();
        // System.out.println("Enter your name");
        // // String name = scanner.next();
        // String name = scanner.nextLine();
        // System.out.println("This is the name :" + name);

        // Scanner scanner = new Scanner("This is DIT \n and this is Dehradun \n adn
        // this is the name");
        // int wordCount = 0;
        // while (scanner.hasNext()) {
        // System.out.println(scanner.nextLine());
        // // scanner.next();
        // // wordCount++;
        // }
        // // System.out.println("This is the word count :" + wordCount);
        // scanner.close();

        // Scanner scanner = new Scanner(System.in);
        // System.out.println("Name :");
        // String name = scanner.nextLine();
        // System.out.println("This is the name :" + name);
        // scanner.close();
        // scanner = new Scanner(System.in);
        // System.out.println("Last name");
        // String name2 = scanner.nextLine();
        // System.out.println("THis is the last name :" + name2);
        // scanner.close();

        // System.out.println("Username :");
        // String name = System.console().readLine();
        // System.out.println("This is the name :" + name);
        // System.out.println("Password :");
        // char[] pwd = System.console().readPassword();
        // System.out.println("This is the password :" + new String(pwd));

        // BuffereReader br = new BuffereReader()


        //tHIs iS DeHRArdUN
        //This Is Dehradun


    }
}
