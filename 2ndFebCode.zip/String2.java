public class String2{
    public static void main(String[] args) {
        // String name = "Shubham";
        // name = name + "Sharma";
        // name = name + "is good";

        // StringBuffer sb = new StringBuffer(50);
        StringBuilder sb = new StringBuilder(50);
        sb.append("Shubham");
        sb.append("Shubham");
        sb.append("Shubham");
        sb.append("Shubham");
        sb.append("Shubham");
        sb.append("Shubham");
        sb.append("Shubham");
        sb.append("Shubham");
        sb.append("Shubham");
        System.out.println(sb.capacity());
        System.out.println(sb.length());
    }
}