

class DOG {
    static DOG obj;

    private DOG() {
    }

    static DOG getInstance() {
        if (obj == null) {
            obj = new DOG();
        }
        return obj;
    }
}

public class SingleTon {
    // DOG dog1 = new DOG();
    // DOG dog2 = new DOG();
    // DOG dog3 = new DOG();
    // DOG dog4 = new DOG();
    DOG dog1 = DOG.getInstance();
    DOG dog2 = DOG.getInstance();
    DOG dog3 = DOG.getInstance();
    DOG dog4 = DOG.getInstance();
}
