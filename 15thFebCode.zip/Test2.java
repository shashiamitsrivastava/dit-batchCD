public class Test2 {

    // static int sumOfSeries(int n) {
    // int sum = 0;
    // String nd = "";
    // for (int i = 1; i <= n; i++) {
    // nd = "";
    // for(int j = 0;j<i; j++){
    // nd = nd + Integer.toString(i);
    // }
    // // term = term * (10 * i) + i;
    // sum += Integer.parseInt(nd);
    // }
    // return sum;
    // }

    public static void main(String[] args) {
        // System.out.println(sumOfSeries(5));

        // int i = 0;
        // while (i < 5) {
        // System.out.print(i + " ");
        // i = i++;
        // }
        // int x = 5;
        // while (x > 0) {
        // x -= 2;
        // System.out.print(x + " ");
        // }

        // int x = 10;
        // while (x > 0) {
        // System.out.print(x + " ");
        // x--;
        // if (x == 5)
        // break;
        // }
        // int i = 0;
        // do {
        // System.out.print(i + " ");
        // i++;
        // } while (i < 0);

        // for (int i = 0; i < 3; i++) {
        // for (int j = 0; j < 3; j++) {
        // if (i == j)
        // continue;
        // System.out.print(i + "" + j + " ");
        // }
        // }

        // int a = 0;
        // a.toString();
        // System.out.println(0x10);

        // int day = 3;
        // switch (day) {
        // case 1:
        // System.out.println("Monday");
        // case 2:
        // System.out.println("Tuesday");
        // case 3:
        // System.out.println("Wednesday");
        // default:
        // System.out.println("Other day");
        // }

        // Integer a = 100;
        // Integer b = 100;
        // System.out.println(a==b);

        int x = 5;
        System.out.println((x > 2) ? (x < 4) ? 10 : 8 : 7);


        int num = 2;
        String result = switch(num) {
            case 1 -> "One";
            case 2 -> "Two";
            default -> "Other";
        };
        System.out.println(result);
        for (int i = 1; i <= 10; i++) {
            if (i %2==0) {
                System.out.print(i + " ");
            }
        }
        

        String name = "Shubham";
        String name2 = new String("Shubham").intern();
        System.out.println(name == name2);
        // byte a = (byte)130;
        // System.out.println(a);

        // double d = Math.sqrt(Double.POSITIVE_INFINITY);
        System.out.println(0x10);

        // for (int i = 0; i < 5; i++) {
        // if (i == 3)
        // continue;
        // System.out.print(i + " ");
        // }

    }
}
