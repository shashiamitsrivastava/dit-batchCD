
import java.util.Date;
import java.util.Locale;
import java.util.Scanner;
import java.util.ResourceBundle;
import java.text.DateFormat;
import java.text.NumberFormat;

public class SalarySlip {

    static Locale locale;

    static ResourceBundle rb;

    // static void createBunlde() {
    // rb = ResourceBundle.getBundle("message", locale);
    // }
    static void createBunlde() {
        rb = ResourceBundle.getBundle("message",
                locale);
    }

    static String formatSalary(double basicSalary) {
        NumberFormat salary = NumberFormat.getCurrencyInstance(locale);
        String temp = salary.format(basicSalary);
        return temp;
    }

    static void printDate() {

        // System.in.read()
        Date dt = new Date();
        DateFormat dtf = DateFormat.getDateInstance(DateFormat.FULL, locale);
        String temp = dtf.format(dt);
        System.out.println("This is the date " + temp);
    }

    static void takeInput() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Please select your language");
        System.out.println("Press 1 for English");
        System.out.println("Press 2 for Hindi");
        System.out.println("Press 3 for French");
        int choice = scanner.nextInt();
        if (choice == 1) {
            locale = new Locale("en", "US");
        } else if (choice == 2) {
            locale = new Locale("hi", "IN");
        } else if (choice == 3) {
            locale = new Locale("fr", "FR");
        }
        createBunlde();
        System.out.println(rb.getString("empID.msg"));
        int empId = scanner.nextInt();
        scanner.nextLine();
        System.out.println(rb.getString("empName.msg"));
        String name = scanner.nextLine();
        System.out.println(rb.getString("basicSal.msg"));
        double basicSalary = scanner.nextDouble();
        calculate(basicSalary, name);
    }

    static void calculate(double basicSalary, String name) {
        double HRA = 0.5 * basicSalary;
        double TA = 0.30 * basicSalary;
        double DA = 0.25 * basicSalary;
        double MA = 0.20 * basicSalary;
        double PF = 0.05 * basicSalary;
        double TAX = calTax(basicSalary);
        String properName = toProperCase(name);
        printData(HRA, TA, DA, MA, TAX, PF, properName);
    }

    static void printData(double HRA, double TA, double DA, double MA, double TAX, double PF, String name) {
        System.out.println("Welcome, " + name);
        System.out.println("This is the Salary Slip");
        System.out.println("Earning \t\t Deductions");
        System.out.println("HRA :" + formatSalary(HRA) + "\t\t TAX: " + formatSalary(TAX));
        System.out.println("TA :" + formatSalary(TA) + "\t\t PF :" + formatSalary(PF));
        System.out.println("DA :" + formatSalary(DA));
        System.out.println("MA :" + formatSalary(MA));
    }

    static double calTax(double basicSalary) {
        double totSal = basicSalary * 12;

        if (totSal < 500000) {
            return 0.0 * basicSalary;
        } else if (totSal > 500000 && totSal < 700000) {
            return 0.10 * basicSalary;
        } else if (totSal > 700000 && totSal < 1000000) {
            return 0.15 * basicSalary;
        }
        return 0.20 * basicSalary;
    }

    static String toProperCase(String name) {
        String nameArray[] = name.split(" ");
        String properName = "";
        for (int i = 0; i < nameArray.length; i++) {

            String firstChar = String.valueOf(nameArray[i].charAt(0)).toUpperCase();
            String remName = nameArray[i].substring(1).toLowerCase();

            properName = properName + " " + firstChar + remName;
        }
        return properName;
    }

    public static void main(String[] args) {
        takeInput();

        // to calc gross salary we have bs +hra+da+ta+ma
        // to net salary we have gs-(tax + pf)

        // Locale
    }
}
