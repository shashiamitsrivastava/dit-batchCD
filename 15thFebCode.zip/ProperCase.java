

import java.util.Scanner;

public class ProperCase {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Please enter a name");
        String name = scanner.nextLine();
        // Shubham Sharma

        String nameArray[] = name.split("");
        // nameArray[0] = shUBhaM
        // nameArray[1] = ShARmA
        String properName = "";
        for (int i = 0; i < nameArray.length; i++) {

            String firstChar = String.valueOf(nameArray[i].charAt(0)).toUpperCase();
            String remName = nameArray[i].substring(1).toLowerCase();

            properName = properName + " " + firstChar + remName;
        }

        System.out.println("This is the proper name :" + properName);
    }
}
