package Questions;

public class Greatest {
    public static void main(String[] args) {
        int first = 9;
        int second = 45;
        int third = 66;

        if (first > second) {
            if (first > third) {
                System.out.println("First");
            } else {
                System.out.println("Third");
            }
        } else {
            if (second > third) {
                System.out.println("Second");
            } else {
                System.out.println("Third");
            }
        }
    }
}
