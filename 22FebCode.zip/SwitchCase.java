package Questions;

public class SwitchCase {
    public static void main(String[] args) {
        int ch = 3;

        // char, int, byte, short JAVA 7 -> String
        // switch (ch) {
        // case 1:
        // System.out.println("This is the first case");
        // break;
        // case 2:
        // System.out.println("This is the sec case");
        // break;
        // case 3:
        // System.out.println("This is the third case");
        // break;
        // case 4:
        // System.out.println("This is the fourth case");
        // break;
        // case 5:
        // System.out.println("This is the fifth case");
        // break;
        // default:
        // System.out.println("This is the default case");
        // break;

        // }

        //  - >
        switch (ch) {
            case 1 -> {

            }
            case 2-> {

            }
            case 3 -> {

            }
            case 4 -> {

            }

            default -> {
                System.out.println("Default");
            }
        }
    }
}
