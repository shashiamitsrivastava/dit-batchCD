package Questions;

public class Temp {
    static String toProperCase(String name) {
        String nameArray[] = name.split(" ");
        String properName = "";
        for (int i = 0; i < nameArray.length; i++) {

            String firstChar = String.valueOf(nameArray[i].charAt(0)).toUpperCase();
            String remName = nameArray[i].substring(1).toLowerCase();

            properName = properName + " " + firstChar + remName;
        }
        return properName;
    }

    public static void main(String[] args) {
        toProperCase("shuBHAm SHarMA");

        System.out.println("कृपया अपनी Emp ID दर्ज करें");
    }
}
