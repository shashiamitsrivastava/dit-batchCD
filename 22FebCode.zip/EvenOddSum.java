package Questions;

public class EvenOddSum {
    public static void main(String[] args) {
        // int num = 12345;
        // int count = 0;
        // int evenSum = 0;
        // int oddSum = 0;
        // while (num != 0) {
        // int last = num % 10;
        // count++;
        // if (count % 2 == 0) {
        // evenSum += last;
        // } else {
        // oddSum += last;
        // }
        // }
        // System.out.println("This is the ODD Sum :" + oddSum);
        // System.out.println("This is the EVEN Sum :" + evenSum);

        int i = 0;
        while (i < 5) {
            System.out.print("Hello ");
            i = i++;
        }

        int ch = 4;
        int res = switch (ch) {
            case 1 -> {
                yield 45;
            }
            case 4 -> {
                yield 54;
            }

            default -> {
                yield 0;
            }
        };
    }
}
