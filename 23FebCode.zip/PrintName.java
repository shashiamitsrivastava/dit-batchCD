public class PrintName {

    static void printName(int count, String name) {
        // this is the base condition
        if (count == 0) {
            return;
        }

        // this is the logic
        System.out.println(name);

        // this is the small problem
        printName(count - 1, name);
    }

    public static void main(String[] args) {
        printName(5, "SHUBHAM");
    }
}
