public class PrintDigit {

    static void printDigit(int count) {
        if (count == 0) {
            return;
        }
        
        printDigit(count - 1);
        System.out.println(count);
    }

    public static void main(String[] args) {
        printDigit(5);
    }
}
