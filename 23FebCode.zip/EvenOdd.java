public class EvenOdd {
    public static void main(String[] args) {
        int a = 9;

        if ((a ^ 1) == a + 1) {
            System.out.println("EVEN");
        } else {
            System.out.println("ODD");
        }

        if ((a & 1) == 0) {
            System.out.println("EVEN");
        } else {
            System.out.println("ODD");
        }
        if ((a | 1) == a + 1) {
            System.out.println("EVEN");
        } else {
            System.out.println("ODD");
        }
    }
}
