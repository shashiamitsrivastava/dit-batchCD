public class Armstrong {
    static int findPower(int base, int exp) {

        if (exp == 0) {
            return 1;
        }

        return findPower(base, exp - 1) * base;
    }

    static int findLenght(int n) {

        if (n == 0) {
            return 0;
        }
        return findLenght(n / 10) + 1;
    }

    static void isArmstrong(int num, int sum, int len) {
        int copy = num;
        int last = num % 10;
        sum = sum + findPower(last, len);
    }

    public static void main(String[] args) {
        // System.out.println(findPower(7, 7));
        // System.out.println(findLenght(456987));
        isArmstrong(153, 0, findLenght(153));
    }
}
