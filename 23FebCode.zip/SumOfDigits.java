public class SumOfDigits {
    static void sum(int n, int sum) {

        if (n == 0) {
            System.out.println("This is the SUM : " + sum);
            return;
        }
        int last = n % 10;
        sum = sum + last;
        sum(n / 10, sum);

    }

    public static void main(String[] args) {
        sum(1234, 0);
    }
}
