 // static int sumOfDigit(int number) {

    // }
